import time
from config import POLLING_INTERVAL
from collector import fetch_threats
from processor import get_severity
from storage import save_csv

def run_soc_pipeline():
    print("🛡️ SOC Threat Intelligence Pipeline Active...")
    while True:
        try:
            raw_threats = fetch_threats()
            if raw_threats:
                for threat in raw_threats:
                    ip = threat.get("ipAddress")
                    country = threat.get("countryCode", "Unknown")
                    score = threat.get("abuseConfidenceScore", 0)
                    
                    severity = get_severity(score)
                    save_csv(ip, country, score, severity)
            
            print(f"Cycle complete. Waiting {POLLING_INTERVAL} seconds...")
            time.sleep(POLLING_INTERVAL)
        except Exception as e:
            print(f"Runtime Error: {e}")
            time.sleep(10) # Error aane par 10 sec wait karega

if __name__ == "__main__":
    run_soc_pipeline()