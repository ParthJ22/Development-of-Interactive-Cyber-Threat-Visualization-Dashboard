# API Configuration
API_KEY = "ac904f7286c7b5a13f527535c46444c4778fde7adee7d5227847bd22fcf853e8"
API_URL = "https://otx.alienvault.com/api/v1/indicators/IPv4/8.8.8.8/general"

# Storage Configuration
DATA_FILE = "real_threats.csv"

# Pipeline Configuration
POLLING_INTERVAL = 10  # seconds
CONFIDENCE_THRESHOLD = 25