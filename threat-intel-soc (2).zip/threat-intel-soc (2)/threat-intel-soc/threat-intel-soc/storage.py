import csv
import os
from datetime import datetime
from typing import Optional
from config import DATA_FILE

def is_duplicate(ip: str) -> bool:
    if not os.path.exists(DATA_FILE):
        return False
    
    with open(DATA_FILE, mode='r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            if row.get('ip') == ip:
                try:
                    log_time = datetime.strptime(row['timestamp'], '%Y-%m-%d %H:%M:%S.%f')
                    if log_time.date() == datetime.now().date():
                        return True
                except (ValueError, KeyError, TypeError):
                    continue
    return False

def save_csv(ip: str, country: str, score: int, severity: str) -> None:
    if is_duplicate(ip):
        return

    file_exists = os.path.isfile(DATA_FILE)
    headers = ["timestamp", "ip", "country", "score", "severity"]
    
    with open(DATA_FILE, "a", newline="", encoding='utf-8') as f:
        writer = csv.writer(f)
        if not file_exists:
            writer.writerow(headers)
        
        writer.writerow([datetime.now(), ip, country, score, severity])