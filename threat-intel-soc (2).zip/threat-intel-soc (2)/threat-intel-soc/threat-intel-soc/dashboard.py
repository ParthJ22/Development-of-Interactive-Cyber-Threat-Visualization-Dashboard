from dash import Dash, dcc, html, Input, Output, dash_table
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import pandas as pd
import numpy as np
from datetime import datetime, timedelta

# ===============================
# LOAD & PREPARE DATA
# ===============================
df = pd.read_csv("real_threats.csv")

# Fix timestamp safely
df["timestamp"] = pd.to_datetime(df["timestamp"], errors="coerce")
df = df.dropna(subset=["timestamp"])

# Ensure required columns exist (SAFE DEFAULTS)
if "severity" not in df.columns:
    df["severity"] = "Unknown"
if "score" not in df.columns:
    df["score"] = 0
if "country" not in df.columns:
    df["country"] = "Unknown"
if "attack_type" not in df.columns:
    df["attack_type"] = "Unknown"
if "mitre" not in df.columns:
    df["mitre"] = "T0000"
if "source_ip" not in df.columns:
    df["source_ip"] = "0.0.0.0"
if "target_system" not in df.columns:
    df["target_system"] = "Unknown"

# Convert ISO-2 → ISO-3 for map compatibility
ISO2_TO_ISO3 = {
    "IN": "IND", "US": "USA", "RU": "RUS", "NL": "NLD",
    "KR": "KOR", "DE": "DEU", "FR": "FRA", "GB": "GBR",
    "CN": "CHN", "JP": "JPN", "BR": "BRA", "CA": "CAN",
    "AU": "AUS", "IT": "ITA", "ES": "ESP", "MX": "MEX"
}
df["country_iso3"] = df["country"].map(lambda x: ISO2_TO_ISO3.get(x, x))

# Add derived columns for better analytics
df["date"] = df["timestamp"].dt.date
df["hour"] = df["timestamp"].dt.hour
df["day_of_week"] = df["timestamp"].dt.day_name()

# Severity ranking for sorting
severity_order = {"Critical": 4, "High": 3, "Medium": 2, "Low": 1, "Unknown": 0}
df["severity_rank"] = df["severity"].map(severity_order)

# ===============================
# DASH APP WITH ENHANCED STYLING
# ===============================
app = Dash(__name__)

# Custom CSS styling
app.layout = html.Div([
    # Header Section
    html.Div([
        html.Div([
            html.H1("🛡️ Interactive Cyber Threat Intelligence Dashboard", 
                   style={"margin": "0", "color": "#00d9ff"}),
            html.P("Real-time Security Incident Monitoring & Analysis Platform",
                  style={"margin": "5px 0", "color": "#a0aec0", "fontSize": "16px"})
        ], style={"flex": "1"}),
        html.Div([
            html.Div(id="total_threats", style={"fontSize": "14px", "color": "#a0aec0"}),
            html.Div(id="last_updated", style={"fontSize": "12px", "color": "#718096"})
        ])
    ], style={
        "background": "linear-gradient(135deg, #1a202c 0%, #2d3748 100%)",
        "padding": "30px",
        "borderRadius": "12px",
        "marginBottom": "20px",
        "boxShadow": "0 4px 6px rgba(0,0,0,0.3)",
        "display": "flex",
        "justifyContent": "space-between",
        "alignItems": "center"
    }),

    # KPI Cards Row
    html.Div([
        html.Div(id="kpi_critical", className="kpi-card"),
        html.Div(id="kpi_high", className="kpi-card"),
        html.Div(id="kpi_countries", className="kpi-card"),
        html.Div(id="kpi_trend", className="kpi-card")
    ], style={
        "display": "grid",
        "gridTemplateColumns": "repeat(auto-fit, minmax(250px, 1fr))",
        "gap": "20px",
        "marginBottom": "20px"
    }),

    # Filter Controls
    html.Div([
        html.Div([
            html.Label("🔍 Severity Filter", style={"color": "#e2e8f0", "fontWeight": "bold", "marginBottom": "8px"}),
            dcc.Dropdown(
                id="severity_filter",
                options=[{"label": s, "value": s} for s in sorted(df["severity"].unique())],
                value=list(df["severity"].unique()),
                multi=True,
                style={"backgroundColor": "#2d3748", "color": "#000"}
            )
        ], style={"flex": "1"}),
        
        html.Div([
            html.Label("📅 Time Range", style={"color": "#e2e8f0", "fontWeight": "bold", "marginBottom": "8px"}),
            dcc.Dropdown(
                id="time_range",
                options=[
                    {"label": "Last 24 Hours", "value": "24h"},
                    {"label": "Last 7 Days", "value": "7d"},
                    {"label": "Last 30 Days", "value": "30d"},
                    {"label": "Last 90 Days", "value": "90d"},
                    {"label": "All Time", "value": "all"}
                ],
                value="7d",
                style={"backgroundColor": "#2d3748", "color": "#000"}
            )
        ], style={"flex": "1"}),
        
        html.Div([
            html.Label("🎯 Attack Type", style={"color": "#e2e8f0", "fontWeight": "bold", "marginBottom": "8px"}),
            dcc.Dropdown(
                id="attack_filter",
                options=[{"label": "All Types", "value": "all"}] + 
                        [{"label": a, "value": a} for a in sorted(df["attack_type"].unique())],
                value="all",
                style={"backgroundColor": "#2d3748", "color": "#000"}
            )
        ], style={"flex": "1"})
    ], style={
        "display": "flex",
        "gap": "20px",
        "background": "#2d3748",
        "padding": "20px",
        "borderRadius": "12px",
        "marginBottom": "20px",
        "boxShadow": "0 2px 4px rgba(0,0,0,0.2)"
    }),

    # Main Charts - First Row
    html.Div([
        html.Div([dcc.Graph(id="trend_chart")], style={"flex": "2"}),
        html.Div([dcc.Graph(id="severity_pie")], style={"flex": "1"})
    ], style={"display": "flex", "gap": "20px", "marginBottom": "20px"}),

    # Geographic Map - Full Width
    html.Div([
        dcc.Graph(id="geo_map")
    ], style={"marginBottom": "20px"}),

    # Second Row - Attack Analysis
    html.Div([
        html.Div([dcc.Graph(id="attack_bar")], style={"flex": "1"}),
        html.Div([dcc.Graph(id="hourly_heatmap")], style={"flex": "1"})
    ], style={"display": "flex", "gap": "20px", "marginBottom": "20px"}),

    # Third Row - MITRE & Vulnerability Analysis
    html.Div([
        html.Div([dcc.Graph(id="mitre_tree")], style={"flex": "1"}),
        html.Div([dcc.Graph(id="top_targets")], style={"flex": "1"})
    ], style={"display": "flex", "gap": "20px", "marginBottom": "20px"}),

    # Anomaly Detection Chart
    html.Div([
        dcc.Graph(id="anomaly_detection")
    ], style={"marginBottom": "20px"}),

    # Top Threats Table
    html.Div([
        html.H3("🚨 Top 10 Critical Threats", style={"color": "#e2e8f0", "marginBottom": "15px"}),
        html.Div(id="threats_table")
    ], style={
        "background": "#2d3748",
        "padding": "20px",
        "borderRadius": "12px",
        "boxShadow": "0 2px 4px rgba(0,0,0,0.2)"
    })

], style={
    "backgroundColor": "#1a202c",
    "minHeight": "100vh",
    "padding": "20px",
    "fontFamily": "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif"
})

# ===============================
# CALLBACK
# ===============================
@app.callback(
    Output("trend_chart", "figure"),
    Output("geo_map", "figure"),
    Output("attack_bar", "figure"),
    Output("mitre_tree", "figure"),
    Output("severity_pie", "figure"),
    Output("hourly_heatmap", "figure"),
    Output("top_targets", "figure"),
    Output("anomaly_detection", "figure"),
    Output("threats_table", "children"),
    Output("kpi_critical", "children"),
    Output("kpi_high", "children"),
    Output("kpi_countries", "children"),
    Output("kpi_trend", "children"),
    Output("total_threats", "children"),
    Output("last_updated", "children"),
    Input("severity_filter", "value"),
    Input("time_range", "value"),
    Input("attack_filter", "value")
)
def update_dashboard(selected_severity, time_range, attack_type):
    
    # Apply filters
    filtered = df[df["severity"].isin(selected_severity)]
    
    # Time range filter
    if time_range != "all":
        cutoff = datetime.now()
        if time_range == "24h":
            cutoff = cutoff - timedelta(hours=24)
        elif time_range == "7d":
            cutoff = cutoff - timedelta(days=7)
        elif time_range == "30d":
            cutoff = cutoff - timedelta(days=30)
        elif time_range == "90d":
            cutoff = cutoff - timedelta(days=90)
        filtered = filtered[filtered["timestamp"] >= cutoff]
    
    # Attack type filter
    if attack_type != "all":
        filtered = filtered[filtered["attack_type"] == attack_type]
    
    # Calculate KPIs
    critical_count = len(filtered[filtered["severity"] == "Critical"])
    high_count = len(filtered[filtered["severity"] == "High"])
    countries_affected = filtered["country"].nunique()
    
    # Trend calculation (compare with previous period)
    if len(filtered) > 0:
        mid_point = len(filtered) // 2
        recent_avg = filtered.tail(mid_point)["score"].mean()
        previous_avg = filtered.head(mid_point)["score"].mean()
        trend = ((recent_avg - previous_avg) / previous_avg * 100) if previous_avg > 0 else 0
    else:
        trend = 0
    
    # 1. TREND CHART - Enhanced with multiple metrics
    daily_stats = filtered.groupby("date").agg({
        "score": ["mean", "sum", "count"]
    }).reset_index()
    daily_stats.columns = ["date", "avg_score", "total_score", "count"]
    
    trend_fig = make_subplots(
        rows=2, cols=1,
        subplot_titles=("Attack Severity Trends Over Time", "Attack Frequency"),
        vertical_spacing=0.12,
        row_heights=[0.6, 0.4]
    )
    
    # Add severity lines
    for sev in filtered["severity"].unique():
        sev_data = filtered[filtered["severity"] == sev].groupby("date")["score"].mean().reset_index()
        trend_fig.add_trace(
            go.Scatter(
                x=sev_data["date"],
                y=sev_data["score"],
                name=sev,
                mode="lines+markers",
                line=dict(width=2)
            ),
            row=1, col=1
        )
    
    # Add frequency bars
    trend_fig.add_trace(
        go.Bar(
            x=daily_stats["date"],
            y=daily_stats["count"],
            name="Attack Count",
            marker_color="#00d9ff"
        ),
        row=2, col=1
    )
    
    trend_fig.update_layout(
        height=600,
        template="plotly_dark",
        paper_bgcolor="#2d3748",
        plot_bgcolor="#1a202c",
        font=dict(color="#e2e8f0"),
        showlegend=True,
        hovermode="x unified"
    )
    
    # 2. GEO MAP - Enhanced with bubble sizes
    geo_data = filtered.groupby("country_iso3").agg({
        "score": "sum",
        "severity": "count"
    }).reset_index()
    geo_data.columns = ["country", "total_score", "attack_count"]
    
    geo = px.choropleth(
        geo_data,
        locations="country",
        locationmode="ISO-3",
        color="total_score",
        hover_data=["attack_count"],
        color_continuous_scale="Reds",
        title="🌍 Global Cyber Threat Heatmap"
    )
    geo.update_layout(
        template="plotly_dark",
        paper_bgcolor="#2d3748",
        geo=dict(bgcolor="#1a202c"),
        font=dict(color="#e2e8f0"),
        height=500
    )
    
    # 3. ATTACK BAR - Horizontal with severity breakdown
    attack_stats = filtered.groupby(["attack_type", "severity"]).size().reset_index(name="count")
    
    attack_bar = px.bar(
        attack_stats,
        y="attack_type",
        x="count",
        color="severity",
        orientation="h",
        title="🎯 Attack Type Distribution by Severity",
        color_discrete_map={
            "Critical": "#dc2626",
            "High": "#f59e0b",
            "Medium": "#eab308",
            "Low": "#22c55e"
        }
    )
    attack_bar.update_layout(
        template="plotly_dark",
        paper_bgcolor="#2d3748",
        plot_bgcolor="#1a202c",
        font=dict(color="#e2e8f0"),
        height=400,
        xaxis_title="Number of Attacks",
        yaxis_title=""
    )
    
    # 4. MITRE TREEMAP - Enhanced
    mitre_tree = px.treemap(
        filtered,
        path=["mitre", "attack_type", "severity"],
        values="score",
        color="severity_rank",
        color_continuous_scale="RdYlGn_r",
        title="🔍 MITRE ATT&CK Technique Analysis"
    )
    mitre_tree.update_layout(
        template="plotly_dark",
        paper_bgcolor="#2d3748",
        font=dict(color="#e2e8f0"),
        height=500
    )
    
    # 5. SEVERITY PIE CHART
    severity_counts = filtered["severity"].value_counts().reset_index()
    severity_counts.columns = ["severity", "count"]
    
    severity_pie = px.pie(
        severity_counts,
        values="count",
        names="severity",
        title="📊 Severity Distribution",
        color="severity",
        color_discrete_map={
            "Critical": "#dc2626",
            "High": "#f59e0b",
            "Medium": "#eab308",
            "Low": "#22c55e"
        },
        hole=0.4
    )
    severity_pie.update_layout(
        template="plotly_dark",
        paper_bgcolor="#2d3748",
        font=dict(color="#e2e8f0"),
        height=400
    )
    
    # 6. HOURLY HEATMAP
    hourly_dow = filtered.groupby(["day_of_week", "hour"]).size().reset_index(name="count")
    day_order = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
    
    heatmap_pivot = hourly_dow.pivot(index="day_of_week", columns="hour", values="count").fillna(0)
    heatmap_pivot = heatmap_pivot.reindex(day_order)
    
    hourly_heatmap = go.Figure(data=go.Heatmap(
        z=heatmap_pivot.values,
        x=heatmap_pivot.columns,
        y=heatmap_pivot.index,
        colorscale="Reds",
        hoverongaps=False
    ))
    hourly_heatmap.update_layout(
        title="⏰ Attack Pattern: Day of Week vs Hour",
        template="plotly_dark",
        paper_bgcolor="#2d3748",
        plot_bgcolor="#1a202c",
        font=dict(color="#e2e8f0"),
        height=400,
        xaxis_title="Hour of Day",
        yaxis_title=""
    )
    
    # 7. TOP TARGETS
    target_stats = filtered.groupby("target_system").agg({
        "score": "sum",
        "severity": "count"
    }).reset_index()
    target_stats.columns = ["system", "total_score", "attack_count"]
    target_stats = target_stats.sort_values("total_score", ascending=False).head(10)
    
    top_targets = px.bar(
        target_stats,
        x="total_score",
        y="system",
        orientation="h",
        title="🎯 Top 10 Targeted Systems",
        color="attack_count",
        color_continuous_scale="Reds"
    )
    top_targets.update_layout(
        template="plotly_dark",
        paper_bgcolor="#2d3748",
        plot_bgcolor="#1a202c",
        font=dict(color="#e2e8f0"),
        height=400,
        xaxis_title="Total Threat Score",
        yaxis_title=""
    )
    
    # 8. ANOMALY DETECTION - Rolling average with std deviation
    daily_counts = filtered.groupby("date").size().reset_index(name="count")
    daily_counts["rolling_mean"] = daily_counts["count"].rolling(window=7, min_periods=1).mean()
    daily_counts["rolling_std"] = daily_counts["count"].rolling(window=7, min_periods=1).std()
    daily_counts["upper_bound"] = daily_counts["rolling_mean"] + 2 * daily_counts["rolling_std"]
    daily_counts["lower_bound"] = daily_counts["rolling_mean"] - 2 * daily_counts["rolling_std"]
    
    anomaly_fig = go.Figure()
    anomaly_fig.add_trace(go.Scatter(
        x=daily_counts["date"],
        y=daily_counts["count"],
        name="Actual Attacks",
        mode="lines+markers",
        line=dict(color="#00d9ff", width=2)
    ))
    anomaly_fig.add_trace(go.Scatter(
        x=daily_counts["date"],
        y=daily_counts["rolling_mean"],
        name="7-Day Average",
        line=dict(color="#22c55e", width=2, dash="dash")
    ))
    anomaly_fig.add_trace(go.Scatter(
        x=daily_counts["date"],
        y=daily_counts["upper_bound"],
        fill=None,
        mode="lines",
        line=dict(color="rgba(255,0,0,0.2)"),
        showlegend=False
    ))
    anomaly_fig.add_trace(go.Scatter(
        x=daily_counts["date"],
        y=daily_counts["lower_bound"],
        fill="tonexty",
        mode="lines",
        line=dict(color="rgba(255,0,0,0.2)"),
        name="Normal Range"
    ))
    
    anomaly_fig.update_layout(
        title="📈 Anomaly Detection - Attack Frequency Analysis",
        template="plotly_dark",
        paper_bgcolor="#2d3748",
        plot_bgcolor="#1a202c",
        font=dict(color="#e2e8f0"),
        height=400,
        xaxis_title="Date",
        yaxis_title="Number of Attacks",
        hovermode="x unified"
    )
    
    # 9. THREATS TABLE
    top_threats = filtered.nlargest(10, "score")[
        ["timestamp", "severity", "attack_type", "country", "source_ip", "target_system", "score"]
    ]
    
    threats_table = dash_table.DataTable(
        data=top_threats.to_dict("records"),
        columns=[{"name": i, "id": i} for i in top_threats.columns],
        style_cell={
            "backgroundColor": "#1a202c",
            "color": "#e2e8f0",
            "border": "1px solid #4a5568",
            "textAlign": "left",
            "padding": "10px"
        },
        style_header={
            "backgroundColor": "#2d3748",
            "fontWeight": "bold",
            "border": "1px solid #4a5568"
        },
        style_data_conditional=[
            {
                "if": {"filter_query": "{severity} = 'Critical'"},
                "backgroundColor": "rgba(220, 38, 38, 0.2)",
                "color": "#fca5a5"
            },
            {
                "if": {"filter_query": "{severity} = 'High'"},
                "backgroundColor": "rgba(245, 158, 11, 0.2)",
                "color": "#fcd34d"
            }
        ]
    )
    
    # KPI Cards Content
    kpi_critical = html.Div([
        html.Div("🔴 CRITICAL", style={"fontSize": "12px", "color": "#fca5a5", "marginBottom": "5px"}),
        html.Div(str(critical_count), style={"fontSize": "32px", "fontWeight": "bold", "color": "#fff"}),
        html.Div("Active Threats", style={"fontSize": "12px", "color": "#a0aec0"})
    ], style=create_kpi_style("#dc2626"))
    
    kpi_high = html.Div([
        html.Div("🟠 HIGH PRIORITY", style={"fontSize": "12px", "color": "#fcd34d", "marginBottom": "5px"}),
        html.Div(str(high_count), style={"fontSize": "32px", "fontWeight": "bold", "color": "#fff"}),
        html.Div("Incidents", style={"fontSize": "12px", "color": "#a0aec0"})
    ], style=create_kpi_style("#f59e0b"))
    
    kpi_countries = html.Div([
        html.Div("🌍 GLOBAL REACH", style={"fontSize": "12px", "color": "#7dd3fc", "marginBottom": "5px"}),
        html.Div(str(countries_affected), style={"fontSize": "32px", "fontWeight": "bold", "color": "#fff"}),
        html.Div("Countries Affected", style={"fontSize": "12px", "color": "#a0aec0"})
    ], style=create_kpi_style("#06b6d4"))
    
    trend_symbol = "↑" if trend > 0 else "↓"
    trend_color = "#f87171" if trend > 0 else "#4ade80"
    kpi_trend = html.Div([
        html.Div("📊 TREND", style={"fontSize": "12px", "color": "#c4b5fd", "marginBottom": "5px"}),
        html.Div(f"{trend_symbol} {abs(trend):.1f}%", style={"fontSize": "32px", "fontWeight": "bold", "color": trend_color}),
        html.Div("vs Previous Period", style={"fontSize": "12px", "color": "#a0aec0"})
    ], style=create_kpi_style("#8b5cf6"))
    
    total_threats_text = f"Total Threats Analyzed: {len(filtered):,}"
    last_updated_text = f"Last Updated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
    
    return (trend_fig, geo, attack_bar, mitre_tree, severity_pie, 
            hourly_heatmap, top_targets, anomaly_fig, threats_table,
            kpi_critical, kpi_high, kpi_countries, kpi_trend,
            total_threats_text, last_updated_text)

def create_kpi_style(border_color):
    return {
        "background": "linear-gradient(135deg, #2d3748 0%, #1a202c 100%)",
        "padding": "20px",
        "borderRadius": "12px",
        "borderLeft": f"4px solid {border_color}",
        "boxShadow": "0 4px 6px rgba(0,0,0,0.3)"
    }

# ===============================
# RUN SERVER
# ===============================
if __name__ == "__main__":
    app.run(host="127.0.0.1", port=8050, debug=True)