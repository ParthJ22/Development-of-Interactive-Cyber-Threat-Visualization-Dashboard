import requests
from typing import List, Dict, Any
from config import API_KEY, API_URL, CONFIDENCE_THRESHOLD

def fetch_threats() -> List[Dict[str, Any]]:
    headers = {"Key": API_KEY, "Accept": "application/json"}
    params = {"confidenceMinimum": CONFIDENCE_THRESHOLD}
    
    # Ye line try se pehle honi chahiye taaki har cycle mein dikhe
    print(f"\n[COLLECTOR] Fetching data from AbuseIPDB (Min Confidence: {CONFIDENCE_THRESHOLD})...")
    
    try:
        response = requests.get(API_URL, headers=headers, params=params, timeout=15)
        response.raise_for_status()
        data = response.json().get("data", [])
        print(f"[COLLECTOR] Successfully fetched {len(data)} potential threats.")
        return data
    except requests.exceptions.RequestException as e:
        print(f"[COLLECTOR] Network Error: {e}")
        return []