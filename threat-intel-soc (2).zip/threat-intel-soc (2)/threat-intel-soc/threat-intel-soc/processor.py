def get_severity(score: int) -> str:
    if not isinstance(score, (int, float)):
        return "Unknown"

    if score >= 90: return "Critical"
    elif score >= 70: return "High"
    elif score >= 40: return "Medium"
    elif score >= 10: return "Low"
    return "Informational"